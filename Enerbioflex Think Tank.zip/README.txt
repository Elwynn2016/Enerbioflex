- Le fichier de connexion � la bdd est configur� pour localhost.
Pour 1&1, renommez le fichier "connexion.php" en "connexionlocal.php" puis le fichier "connexion1.php" en "connexion.php".

- La bdd � inclure est "enerbioflex.sql". Elle contient les tables par d�faut.
Utilisez "enerbioflex_ex.sql" si vous voulez des exemples dans chaques tables (articles, forum, membre, visio, messages).

- La bdd est � inclure avant la premi�re connexion � l'espace membre.

- Pour activer l'espace membre, rendez-vous sur "Se Connecter". Nommez la bdd comme elle se nomme dans PhpMyAdmin.