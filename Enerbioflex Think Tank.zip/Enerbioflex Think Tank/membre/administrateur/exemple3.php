<?php session_start();
include('header.php');
include('menuExemple.php');
?>
<div id="principal">
<div id="titre_principal">Cadre 1</div>
Votre texte ici</div>
<div id="principal">
<div id="titre_principal">Cadre 2</div>
Votre texte ici</div>
<?php
include('footer.php');
?>