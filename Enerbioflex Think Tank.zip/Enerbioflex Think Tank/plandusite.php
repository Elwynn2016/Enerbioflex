<?php
include('header_simple.php');
?>
<h1>Plan du Site ENERBIOFLEX</h1>
<hr width="100%" color="7ad443">
<ul>
<li>
Membre
<br/><a  href= "membre/index.php">> Identification</a>
<br/><a href="membre/inscription.php">> Crée un nouveau compte</a>
</li>
</ul>

<br/>
<ul>
<li>
Menu
<br/><a href="articles/articles.php">> Article</a>
<br/><a href="forum/forum.php">> Forum</a>
<br/><a href="visio/visio.php">> VisioConférences</a>
<br/><a href="membre/membre/index.php">> Membre </a>
<br/><a href="infos.php">> Infos Pratiques </a>
</li>
</ul>

<br/>
<ul>
<li>
VisioConférence
<br/><a href="visio/visio.php">> Menu</a>
<br/><a href="visio/newvisio.php">> Programmer une VisioConférence</a>
</li>
</ul>

<br/>
<ul>
<li>
Article
<br/><a href="articles/menuArticle.php">> Menu Article</a>
<br/><a href="articles/articles.php">> Article</a>
<br/><a href="articles/creerArticle.php">> Créer un article </a>
</ul>
</li>

<br/>
<ul>
<li>
Forum
<br/><a href="forum/menuforum.php">> Menu Forum</a>
<br/><a href="forum/forum.php">> Forum </a>
<br/><a href="forum/creeSujet.php">> Créer un topic </a>

</li>
</ul>

<?php
include('footer_simple.php');
?>







