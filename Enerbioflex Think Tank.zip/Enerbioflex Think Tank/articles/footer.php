<?php
	$folder='../';
	include('../footer.php');
?>