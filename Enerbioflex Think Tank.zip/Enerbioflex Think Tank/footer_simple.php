		<p> <a id="retour" href = "<?php echo $folder ?>accueil.php" > < Retourner à l'accueil </a></p>
	</body>
</html>