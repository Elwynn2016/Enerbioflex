<?php
include("header.php")
?>

<h1> Erreur </h1>
<hr width="100%" color="2a95be"/>
<p> La page que vous avez demandée n'existe pas ou a été supprimée.</p> 
<img id="erreur" src="Images/erreur.jpg" alt="erreur" /> 

<?php
include("footer.php")
?>