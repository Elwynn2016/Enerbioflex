<?php
	$folder='../';
	include($folder.'function.php');
	include($folder.'header.php');
	//echo '<link rel="stylesheet" type="text/css" href="forum.css">';
?>